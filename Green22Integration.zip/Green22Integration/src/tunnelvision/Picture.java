package tunnelvision;
import java.util.Timer;
import java.util.TimerTask;
import swiftbot.SwiftBotAPI;
import swiftbot.SwiftBotAPI.ImageSize;
import swiftbotressources.Ressources;

public class Picture {
	static SwiftBotAPI pixel = Ressources.APIinstance();

	public static void main(String[] args) {
		Timer second = new Timer();

//		Repeat code inside every 2 seconds
		TimerTask tt = new TimerTask() {
			@Override
			public void run() {
//				Taking picture 
				try {
					pixel.takeGrayscaleStill("/home/pi/Documents", "TunnelImage", ImageSize.SQUARE_48x48);
				} catch (Exception e) {
					e.printStackTrace();
				}
			};
		};
////	1000ms = 1 second   //picture taken every 1 seconds
		second.scheduleAtFixedRate(tt, 500, 1000);
//		second.cancel();
	}

}
