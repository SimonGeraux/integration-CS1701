package tunnelvision;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import com.hopding.jrpicam.exceptions.FailedToRunRaspistillException;
import swiftbot.SwiftBotAPI;
import swiftbot.SwiftBotAPI.ImageSize;
import swiftbotressources.Resources;

public class LightIntensity {
	static SwiftBotAPI pixel = Resources.APIinstance();
	static int count = 0;
	static int count1 = 0;
	public static void main(String[] args) throws IOException {

//		taking picture
		try {
			pixel.takeGrayscaleStill("/home/pi/Documents", "TunnelImage", ImageSize.SQUARE_48x48);
		} catch (IOException | FailedToRunRaspistillException | InterruptedException e) {
			e.printStackTrace();
		}
//		retrieving image
		BufferedImage img = ImageIO.read(new File("/home/pi/Documents//TunnelImage.png"));

		
//		finding luminance of every pixel in the 48x48
		for (int x = 0; x < img.getWidth(); x++)
			for (int y = 0; y < img.getHeight(); y++) {
//				Get RGB of every pixel
				int sRGB = img.getRGB(x, y);
				
//				extracting colour component	
//				colour ordinates for sRGB r=0.64 g=0.3 b=0.13
				int red = (sRGB >>> 16 & 0xFF);
				int green = (sRGB >>> 8& 0xFF);
				int blue = (sRGB >>> 0& 0xFF);

//			calculated luminance using sRGB luminance constants
				float grayscalePixel = ((float) ((0.21 * red) + (0.71 * green) + (0.07 * blue)) / 255);
				String o = "outside tunnel";
				String i = "inside tunnel";
				if (grayscalePixel >= 0.5f) {
					count++;
					System.out.println(o);
//					return o;
				} else {
					count1++;
					System.out.println(i);
//					return i;
				}
			}
//		int count;
//		int count1;
		return;

	}	
	public static int getLightIntensity() {
		if (count > count1) {
			return 0;
		} else {
			return 1;
			}
			}
	}

