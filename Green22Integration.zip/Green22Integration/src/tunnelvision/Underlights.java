package tunnelvision;
import java.io.IOException;
import swiftbot.SwiftBotAPI;

public class Underlights extends TunnelNumber {

	static SwiftBotAPI pixel = new SwiftBotAPI();

	public static void turnUnderlightsRed() {
//		 set underlights to red
		try {
			pixel.fillUnderlights(255, 0, 0);
			pixel.updateUnderlights();
			Thread.sleep(5000);
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void turnUnderlightsBlue() {
//			set underlights to blue
		try {
			pixel.fillUnderlights(0, 0, 255);
			pixel.updateUnderlights();
			Thread.sleep(5000);
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}

	}
}
