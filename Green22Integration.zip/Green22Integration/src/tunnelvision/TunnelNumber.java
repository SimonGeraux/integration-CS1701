package tunnelvision;
import java.util.Scanner;

public class TunnelNumber {
	private static int tunnelNumber;

//	      method covers requirements 2,3
	public void setTunnelNumber() {
		System.out.println("Welcome to tunnel vision \n" 
	            + "\nHow many tunnels are there? " 
				+ "\nMinimum=3"
	            +"\nMaximum=6");

			Scanner tunnel1 = new Scanner(System.in);
			System.out.print("Enter:");
//			Whatever number the user inputs next will be scanned
			int tunnelNumber = tunnel1.nextInt();

//         code wouldn't work correctly without nested loop
			if (tunnelNumber < 3 ||tunnelNumber >6) {
				do {
//					error message and asking user to repeat if input is <3
					System.out.println("Welcome to tunnel vision" 
				+ "\nError:Must be a minimum of 3 tunnels and maximum of 6"
				+ "\nPlease try again \n "
				+ "\nHow many tunnels are there? "
				+ "\nMinimum=3"
				+"\nMaximum=6");
					System.out.print("Enter:");
					 int tunnelNumber1 = tunnel1.nextInt();
					tunnelNumber = tunnelNumber1;
			} while (tunnelNumber < 3 || tunnelNumber > 6);}
	    }

	public int getTunnelNumber() {
		return tunnelNumber;
	}


}
