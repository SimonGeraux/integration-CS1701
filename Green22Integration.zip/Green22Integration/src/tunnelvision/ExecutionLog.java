package tunnelvision;
public class ExecutionLog {
	private static long duration;

//	Do you wish to view a display of the log of execution?
	public static void main(String[]args) {
		System.out.println("Do you wish to view a display of the log of execution?");
	}

	public static void setDuration() throws InterruptedException, Exception{
		Move m = new Move();
		long startTime = System.currentTimeMillis();
		m.move();
		long endTime = System.currentTimeMillis();
		System.out.println("The Swiftbot moved for" 
		+ ((endTime - startTime) / 1000) + " seconds");
		duration=((endTime- startTime)/1000);
	}

	public long getDuration() {
		return duration;
	}

	public static void TotalDistance() {
//      Distance = Speed *Time
//		speed = 30// time = Duration
//		30 cm in 3 seconds 30 velocity

	}

}
