package tunnelvision;
import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;
import swiftbot.SwiftBotAPI;
import swiftbotressources.Resources;

public class TunnelVision {
	SwiftBotAPI pixel = Resources.APIinstance();

	public static void main(String[] args) throws InterruptedException, Exception {
		TunnelNumber t = new TunnelNumber();
		Exit e = new Exit();
		Move m = new Move();

		t.setTunnelNumber();
//		couldn't make work
//		e.pressX();
		{
			SwiftBotAPI pixel = Resources.APIinstance();
			t.getTunnelNumber();
			if (t.getTunnelNumber() >= 3 || t.getTunnelNumber() <= 6) {
				System.out.println("Press Button X if you wish to stop TunnelVision early");
				pixel.startMove(30, 30);
				pixel.BUTTON_X.addListener(new GpioPinListenerDigital() {
					public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
						{
							if (event.getState().isLow()) {
								pixel.stopMove();
//								ask for log and stuff
								pixel.BUTTON_X.removeAllListeners();
							}
						}
					}
				});
				;

			}
		}
		m.move();
		e.exit();
	}

}
