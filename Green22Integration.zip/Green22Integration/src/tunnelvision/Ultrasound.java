package tunnelvision;
import swiftbot.SwiftBotAPI;
import swiftbotressources.Ressources;

public class Ultrasound {
	static SwiftBotAPI pixel = Ressources.APIinstance();
	public double setTunnelDistancel()throws Exception {
		double distance = pixel.useUltrasound();
		return distance;}
	public void inTunnel() throws InterruptedException, Exception {
		Ultrasound u = new Ultrasound();
//		pixel= 30 cm 3 seconds 30 velocity
		pixel.move(30, 30, (int) (u.setTunnelDistancel()*100));
		pixel.stopMove();
	}
	public double setOutOfTunnelDistance() throws InterruptedException {
		SwiftBotAPI pixel = Ressources.APIinstance();
		double distance = pixel.useUltrasound();
		return distance;}
	public void outOfTunnel() throws InterruptedException {
		Ultrasound u = new Ultrasound();
//		pixel= 30 cm 3 seconds 30 velocity#
		pixel.startMove(30,30);
		pixel.move(30, 30, (int) (u.setOutOfTunnelDistance()*100));
		pixel.stopMove();
	}
	public static void main(String[]args) throws Exception {
		Ultrasound u = new Ultrasound();
		u.inTunnel();
		u.outOfTunnel();
		
	}

}
