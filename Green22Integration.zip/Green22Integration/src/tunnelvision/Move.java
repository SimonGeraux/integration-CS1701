package tunnelvision;
import java.io.IOException;

import swiftbot.SwiftBotAPI;
import swiftbotressources.Resources;

public class Move {

	public void move() throws InterruptedException, Exception {
		SwiftBotAPI pixel = Resources.APIinstance();
		Ultrasound u = new Ultrasound();
//		Underlights un = new Underlights();
		TunnelNumber t = new TunnelNumber();
		
		int number = t.getTunnelNumber();
		for (int x = 0;x!=number;x++) {
//		not working when i call as object
		try {
			pixel.fillUnderlights(255, 0, 0);
			pixel.updateUnderlights();
			Thread.sleep(5000);
		} catch (IOException | InterruptedException e1) {
			e1.printStackTrace();
		}
		
		u.inTunnel();
		
		try {
			pixel.fillUnderlights(0, 0, 255);
			pixel.updateUnderlights();
			Thread.sleep(5000);
		} catch (IOException | InterruptedException e1) {
			e1.printStackTrace();}
		
		u.outOfTunnel();
		
		try {
			pixel.fillUnderlights(255, 0, 0);
			pixel.updateUnderlights();
			Thread.sleep(5000);
		} catch (IOException | InterruptedException e1) {
			e1.printStackTrace();
		}  
	}
		}
	}
