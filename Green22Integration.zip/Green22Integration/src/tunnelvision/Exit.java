package tunnelvision;
import java.util.Scanner;

import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;
import swiftbot.SwiftBotAPI;
import swiftbotressources.Resources;

public class Exit extends TunnelNumber {
	SwiftBotAPI pixel = Resources.APIinstance();
	
	public void exit() {
		pixel.BUTTON_X.removeAllListeners();
		pixel.stopMove();
		System.out.println("Do you wish to view a display of the log of execution? "
				+ "\nType Yes if you do");
			String y = Resources.userinput();
			ExecutionLog log = new ExecutionLog();
			
			if(y == "yes"|| y =="Yes"|| y =="YES") {
				System.out.println("Total duration " + log.getDuration());
				System.exit(0);
			}
		}
	
	
	
	public void pressX() {
	
		TunnelNumber t = new TunnelNumber();
		Exit e = new Exit();
		t.getTunnelNumber();
		if (t.getTunnelNumber() >= 3 || t.getTunnelNumber() <= 6) {
			System.out.println("Press Button X if you wish to stop TunnelVision early");
			pixel.startMove(30, 30);
			pixel.BUTTON_X.addListener(new GpioPinListenerDigital() {
				public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
					{
						if (event.getState().isLow()) {
							pixel.stopMove();
//							ask for log and stuff
							e.exit();
//							pixel.shutdown();
							System.exit(0);
							pixel.BUTTON_X.removeAllListeners();

						}
					}
				}
			});
			;

		}
	}
}
