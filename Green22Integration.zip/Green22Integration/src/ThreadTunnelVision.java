import tunnelvision.MainTunnelVision;

public class ThreadTunnelVision implements Runnable{

	@Override
	public void run() {
		MainTunnelVision tunnelvision = new MainTunnelVision();
		try {
			String[] args = null;
			tunnelvision.main(args);
		} catch (Exception e) {}	
	}

}
