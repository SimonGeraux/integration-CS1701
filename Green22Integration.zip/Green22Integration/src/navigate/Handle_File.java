package navigate;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Handle_File extends Helper {

    String file_name = System.getProperty("user.dir") + "/Logged_Commands.txt";
    public File file = new File(file_name);
    ArrayList<String[]> logged_commands_from_file = new ArrayList<>();
    ArrayList<String> lines_from_file = new ArrayList<>();
    int already_logged_commands;


    public Handle_File( int already_logged_commands) {

        // number of movement commands SwiftBot made
        this.already_logged_commands = already_logged_commands;

        // if the the file doesn't exist, then outputs a title to a new file
        if (!file.exists())
            title_of_file();

        // reads lines into the 'lines_from_file' array
        get_file_content();


        // the commands will be logged to an arraylist
        commands_from_file();
    }

    public void main() {

        // checks the command user chose
        if (current_command_letter == "W") {
            // object handles logging movement commands in a file
            new W_Command( logged_commands_from_file, already_logged_commands,
                    file_name, lines_from_file).run();

        } else if (current_command_letter == "X") {
            // object displays and executes movement commands from a file
            new X_Command(logged_commands_from_file).run();
        } else if (current_command_letter == "D") {
            delete_file();
        }
    }

    void title_of_file() {
        try {
            // creates a new file if it does not exit
            if (!file.exists()) {
                // outputs title to file
                FileWriter writer = new FileWriter(file_name);
                writer.write("Logged Commands For The Movement Of The SwiftBot\n");
                writer.write("================================================\n");
                writer.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    void get_file_content() {
        try {
            // reads from file
            BufferedReader reader = new BufferedReader(new FileReader(file_name));

            // puts the content in an array
            this.lines_from_file = reader.lines().collect(Collectors.toCollection(ArrayList::new));

            reader.close();
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    void commands_from_file() {

        // goes through each line from the file
        for (String line : lines_from_file) {

            Pattern p = Pattern.compile("^\\t[A-Z] \\d+ \\d*");
            Matcher m = p.matcher(line);


            while (m.find()) {

                // splits the command into its inputs and puts into string array
                String[] command = line.trim().split(" ");
                // adds the command to an arraylist
                this.logged_commands_from_file.add(command);

            }
        }


    }

    void delete_file() {
        if (file.exists()) {
            // deletes file containing the logged commands
            file.delete();
            System.out.println("  The file containing the logged commands has been delete ");
            line(70);

        } else {
            System.out.println("  No text file has been created to delete");
            line(70);
        }
    }
}
