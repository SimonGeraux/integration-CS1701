package navigate;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

public class W_Command extends Helper {

	ArrayList<String[]> logged_commands_from_file = new ArrayList<String[]>();
	ArrayList<String> lines_from_file = new ArrayList<>();
	int already_logged_commands;
	String file_name;

	public W_Command(ArrayList<String[]> logged_commands_from_file, int already_logged_commands, String file_name,
			ArrayList<String> lines_from_file) {

		this.logged_commands_from_file = logged_commands_from_file;
		this.already_logged_commands = already_logged_commands;
		this.lines_from_file = lines_from_file;
		this.file_name = file_name;
	}

	// will first check cases where the file should not be written to and it can
	// then run the
	// process
	void run() {

		// if there is no commands in the array list, it will display this message
		if (all_movement_commands.size() == 0) {

			System.out.println("  No movement commands have been made to logged");
			line(70);

		}

		// if all the commands are already logged, it will display this message
		else if (already_logged_commands == all_movement_commands.size()) {

			System.out.println("  All previous commands has been logged already");
			line(70);

		} else {

			// write to file and display to command line
			try {

				// outputs the time commands were saved to the file and command line
				log_time_saved();
				// outputs the commands to the file and command line
				log_commands();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// LOGGING DATE AND TIME

	// writes to file the time the commands were logged
	void log_time_saved() throws IOException {
		FileWriter writer = new FileWriter(file_name, true);

		if (logged_commands_from_file.size() == 0 || (!previous_date_saved().equals(get_current_date()))) {

			writer.append("\nProgram started on " + get_current_date());
			writer.append("\n-------------------------------\n");
		}

		writer.append(" Commands saved at " + current_time() + "\n");
		writer.close();

		// outputs to console when the commands were logged
		System.out.println("  These are movement commands has been logged at " + current_time());
		line(70);
	}

	String previous_date_saved() {

		String date = "";

		// checks if there are any commands saved
		if (this.logged_commands_from_file.size() > 0) {
			// sets it to the index of the previous logged date
			int last_opened_index = this.lines_from_file.lastIndexOf("-------------------------------") - 1;

			// sets it to the line of the previous logged date
			String[] last_opened_date = this.lines_from_file.get(last_opened_index).split(" ");

			// sets date from the line
			String month = last_opened_date[last_opened_date.length - 2];
			String day_of_month = last_opened_date[last_opened_date.length - 1];
			date = month + " " + day_of_month;
		}
		return date;
	}

	public String current_time() {
		// gets the current date
		Calendar calendar = Calendar.getInstance();
		int hour = calendar.get(Calendar.HOUR);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);

		// formats time
		String hour_two_digit = hour < 10 ? "0" + hour : String.valueOf(hour);
		String time = hour_two_digit + ":" + minute + ":" + second + ":";

		return time;
	}

	public String get_current_date() {
		String[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

		// gets the current date
		Calendar calendar = Calendar.getInstance();
		int month = calendar.get(Calendar.MONTH);
		int date = calendar.get(Calendar.DAY_OF_MONTH);
		System.out.println();

		return months[month] + " " + date;
	}

	// LOGGING COMMANDS

	void log_commands() throws IOException {


		// loops through each command
		for (int i = this.already_logged_commands; i < all_movement_commands.size(); i++) {

			// gets command
			String[] command = all_movement_commands.get(i);

			// files command
			command_saved(command);

			// displays logged command
			new Move_Swiftbot(command).display_command();
		}

	}

	void command_saved(String[] command) throws IOException {
		// outputs title to file
		FileWriter writer = new FileWriter(file_name, true);
		writer.append("\t");
		// loops each input needs for the command
		for (String input : command) {
			writer.append(input + " ");
		}
		writer.append("\n");
		writer.close();

	}
}
