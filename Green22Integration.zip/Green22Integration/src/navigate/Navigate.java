package navigate;

public class Navigate extends Helper {

	public static int already_logged_commands;

	public static void main(String[] args) {

		// title
		line(80, "=", "");
		System.out.printf("\n%-17sProgram for the navigating the Swiftbot\n\n", "");
		line(80, "=", "");

		// runs the main loop for the program
		run();
	}

	static void run() {

		// keeps while loop running
		boolean running = true;


		// the while loop will go on asking and then executing the commands the user wants
		while (running) {

			// lets the user chose the command they want to run
			new Choose_Command().run();

			// runs command user chose
			handle_commands();

			// draws a line after the command is done except the 'Q' command
			if (current_command_letter != "Q")
				line(80, "\"", "\n\n");
			else
				running = false; // stops loop
		}
	}

	/*
	 * determines what command the user chose and then executing the appropriate object that deals
	 * with it
	 */
	static void handle_commands() {

		switch (current_command_letter) {
			// movement commands
			case "F": // forward movement
			case "B": // backward movement
			case "L": // left movement
			case "R": // right movement
				new Movement_Commands().main();
				break;

			// retracing commands
			case "T": // previous movements specified by user
			case "A": // all previous movements
			case "V": // last movement
				new Retrace_Movements().run();
				break;

			// 'E' command
			case "E": // erase all previous movement commands
				E_command();
				break;

			// handles file
			case "W": // logging movements
			case "X": // executing logged movements
			case "D": // deleting the file of the logged commands

				// creates the object that handles the files for the movement commands
				new Handle_File(already_logged_commands).main();
				set_already_logged_command();
				break;


			// 'Q' command to terminate the program
			case "Q":
				// displays to the user
				System.out.println(" The program has ended.");
				line(22, "#", " ");

			default:
				break;
		}
	}

	static void E_command() {
		
		// checks if there are no commands
		if (all_movement_commands.size() == 0) {
		
			System.out.println("  All the commands you ran to move the Swiftbot have been erased ");
			line(70);

		} else {
			// resets the variables to do with keeping track of movement and retracing command 
			all_movement_commands.removeAll(all_movement_commands);
			already_logged_commands = 0;
			// lets the user know that the commands are erased 
			System.out.println("  No movement commands have been ran to erase ");
			line(70);
		}

	}

	static void set_already_logged_command() {

		// sets the variable to length to the number of all_movement_commands array list
		if (current_command_letter == "W") {

			already_logged_commands = all_movement_commands.size();

		}
		// sets the variable to zero
		else if (current_command_letter == "D") {

			already_logged_commands = 0;

		}

	}
}
