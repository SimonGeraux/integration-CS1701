package navigate;

import swiftbot.SwiftBotAPI;
import swiftbotressources.Ressources;

public class Move_Swiftbot {

	SwiftBotAPI swiftBot;
	String letter_for_direction;
	int duration_in_milliseconds;
	int command_retracing_number;
	int speed;
	int leftVelocity;
	int rightVelocity;

	public Move_Swiftbot() {}

	// the input fore movement commands
	public Move_Swiftbot(String[] movement_command) {

		this.letter_for_direction = movement_command[0];

		this.duration_in_milliseconds = Integer.parseInt(movement_command[1]) * 1000;

		if (this.letter_for_direction.equals("T") || this.letter_for_direction.equals("V")
				|| this.letter_for_direction.equals("A"))
			this.command_retracing_number = Integer.parseInt(movement_command[1]);
		else
			this.speed = Integer.parseInt(movement_command[2]);

	}

	public void run(boolean last_command) {

		// displays the inputs for the movement command
		display_command();

		// wraps the api variable in a try/catch block and handling the error when IZC
		// is disabled
		try {
			swiftBot = Ressources.APIinstance();
		} catch (Exception e) {
			System.out.println("\nThe I2C has been disabled!");
			System.out.println("Enter this command:");
			System.out.println("sudo raspi-config nonint do_i2c 0\n");
		}

		// this method executes the movement command
		move();

		// shutting down each the Swiftbot's movement stop

		// display to user that movement is done
		movement_finished(last_command);
	}

	// displays the inputs for a movement command
	public void display_command() {
		System.out.println("   -------------------------------------------------");

		// input: letter
		System.out.print("   |  Command Letter: '" + this.letter_for_direction + "'| ");

		// checks if it is a retracing command or just a movement one
		if (this.letter_for_direction.equals("T") || this.letter_for_direction.equals("V")
				|| this.letter_for_direction.equals("A")) {
			// input: retracing number
			System.out.printf("| Retracing number: %-4s|", 1);
		} else {
			// input: number of second
			System.out.print("Duration: " + this.duration_in_milliseconds / 1000);
			// input: number for speed percentage
			System.out.printf(" | Speed: %-3s|", this.speed);
		}

		System.out.println("\n   -------------------------------------------------");
	}

	void move() {
		/*
		 * checks what direction the user inputted via the letter for command and sets the speed of the
		 * left and right wheel accordingly
		 */
		switch (this.letter_for_direction) {
			case "F": // FORWARD
				System.out.println("\tThe Swiftbot is moving forward...\n");
				this.leftVelocity = speed;
				this.rightVelocity = speed;
				break;
			case "B": // BACKWARD
				System.out.println("\tThe Swiftbot is moving backward...\n");
				this.leftVelocity = speed * -1;
				this.rightVelocity = speed * -1;
				break;
			case "R": // RIGHT
				System.out.println("\tThe Swiftbot is turning right...\n");
				this.leftVelocity = this.speed;
				this.rightVelocity = 0;
				break;
			case "L": // LEFT
				System.out.println("\tThe Swiftbot is turning left...\n");
				this.leftVelocity = 0;
				this.rightVelocity = this.speed;
				break;

		}

		// moves the Swiftbot
		try {
			swiftBot.move(leftVelocity, rightVelocity, duration_in_milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void movement_finished(boolean last_command) {
		/*
		 * if the user runs more than one command, it will wait till the last one to display that the
		 * movement is finished, which the last_command parameter will indicate
		 */
		if (last_command) {
			System.out.println("   The SwiftBot has finished moving");
			System.out.println("   ################################");
		}
	}
}
