package navigate;

import java.util.*;
import java.util.stream.Collectors;


public class Retrace_Movements extends Helper {
	List<String[]> initial_movement_commands;
	int retracing_number;

	public Retrace_Movements() {
		/*
		 * this list filters out the 'T', 'A' and 'V' commands and keeps the other movement commands
		 */
		this.initial_movement_commands =
				all_movement_commands.stream().filter(command_letter -> command_letter[0] != "T"
						&& command_letter[0] != "A" && command_letter[0] != "V").collect(Collectors.toList());

	}

	public void run() {

		// the process will not continue if there is no movement commands
		if (all_movement_commands.size() == 0) {

			System.out.println("  No movement commands have been made to retrace");
			line(70);

		} else {
			// sets the retracing number depending on the current command letter
			set_retracing_number();

			// displays and runs the previous commands
			run_movement_commands_in_reverse();

			// add the current command to all_movement_commands arraylist
			add_current_retracing_command();
		}

	}

	// RETRACING NUMBER

	void set_retracing_number() {
		/*
		 * checks whether the letter is a 'T' 'A', or 'V' to know how many movement commands to retrace
		 */
		if (current_command_letter == "T") {
			prompt();
			// this method will ask the user to input how many movement commands to retraced
			set_retracing_number_for_T_command();
			System.out.println();

			// These are the inputs for the movement command you chose
			System.out.println("\n   These are the inputs for retracing the '" + this.retracing_number
					+ "' previous movement\\s");
			line(70);

		} else if (current_command_letter == "A") {

			// sets retracing_number to the length of the movement commands the user previously
			// ran
			this.retracing_number = initial_movement_commands.size();

			// lets the user know that the last movement will be executed
			System.out.print("  These are the inputs for retracing all the previous movements  \n");
			line(70);
		} else {

			// sets retracing_number to 1 as only the last command will be executed
			this.retracing_number = 1;

			// lets the user know that the last movement will be executed
			System.out.print("  These are the inputs for repeating the last previous movement  \n");
			line(70);
		}
	}

	// asking for the user to input a number to retrace
	void run_movement_commands_in_reverse() {

		// loop starts at the end of the arraylist of commands
		int start = this.initial_movement_commands.size() - 1;

		// loop ends at the number of steps user chose
		int end = this.initial_movement_commands.size() - this.retracing_number;

		// runs a for loop backward, so the recent commands can be executed first
		for (int i = start; i >= end; i--) {
			// this method displays and executes the movement command
			new Move_Swiftbot(this.initial_movement_commands.get(i)).run(i == end);

		}
	}

	void add_current_retracing_command() {
		// an array consisting of the command letter and the retracing number
		String[] T_command_inputs = {current_command_letter, String.valueOf(retracing_number)};
		// add T_command_inputs array to all_movement_commands array list
		all_movement_commands.add(T_command_inputs);

	}

	// RETRACING NUMBER FOR T COMMAND

	void prompt() {

		// title for input
		System.out.println("  Number for retracing");
		line(70);

		// information for input
		System.out.println("   There are up to " + initial_movement_commands.size()
				+ " previous movement command\\s you can retrace \n\n   How many previous movements do you want the program to retrace? ");

		// prompt for input
		line(63, ">", "   ");
		System.out.print("\n   Enter the retracing number here: ");

	}

	void set_retracing_number_for_T_command() {
		// for the while loop
		boolean invalid = true;

		// loops until user input is not invalid
		while (invalid) {

			// enters input
			String input_string = reader.nextLine();

			// the try/catch block handles the input when it is not a valid integer
			try {
				invalid = is_input_valid_for_T_command(input_string);

			} catch (Exception e) {

				// error message for when the input is invalid
				if (this.initial_movement_commands.size() == 1) {
					System.out.print("\n   '" + input_string
							+ "' is not a valid option. Only 1 movement command has ran. Enter a number here: ");
				} else {
					System.out.print(
							"\n   '" + input_string + "' is not a valid option. Enter a number between 1 to "
									+ this.initial_movement_commands.size() + " here: ");
				}
			}

		}
	}

	boolean is_input_valid_for_T_command(String input_string) {
		// the input is an integer
		int input_number = Integer.parseInt(input_string);
		// checks if the integer is below zero and above the number of commands
		if (input_number > 0 && input_number <= this.initial_movement_commands.size()) {
			// sets the number to inputted number
			this.retracing_number = input_number;
			// breaks out of the loop
			return false;
		}
		// throwing an error if number is greater than the number of commands
		else
			throw new ArrayIndexOutOfBoundsException();
	}



}
