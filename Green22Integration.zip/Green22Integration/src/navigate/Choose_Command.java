package navigate;

import java.util.LinkedHashMap;
import java.util.Scanner;
public class Choose_Command extends Helper {

    LinkedHashMap<String, String> commands = new LinkedHashMap<String, String>();
    String[] command_letters = {"F", "B", "L", "R", "T", "A", "V", "E", "X", "W", "D", "Q"};


    public void run() {

        // sets the description of the commands
        set_commands();

        // displays the list of commands
        display_table_commands();

        // ask the user what command they want to be executed
        get_command_letter_from_user();

        // line after the user chooses the command
        line(80, "\"", "\n\n");

        // displays the description of the command chosen
        display_command_description();
    }

    void set_commands() {
        // the description of the commands
        commands.put("F", "Move Swiftbot forward ");
        commands.put("B", "Move Swiftbot backward ");
        commands.put("L", "Turn Swiftbot left ");
        commands.put("R", "Turn Swiftbot right ");
        commands.put("T", "Retrace a number of previous movements of your choice ");
        commands.put("A", "Retrace all previous movements ");
        commands.put("V", "Repeat the last movement ");
        commands.put("E", "Erase all the previous commands that moved the Swiftbot  ");
        commands.put("W", "Log previous movements in a text file ");
        commands.put("X", "Execute previous movements from the text file ");
        commands.put("D", "Delete the file containing previous movements ");
        commands.put("Q", "Exit the program");

    }

    void display_table_commands() {

        // table title
        System.out.println("\nCommands to navigate the Swiftbot");
        line(34, "*", "");

        // row - header
        line(71, "-", "  ");
        System.out.printf("  | Command | description%48s\n", "|");
        line(71, "-", "  ");

        // row - commands
        for (String letter : commands.keySet()) {
            int space_to_the_right = 59 - commands.get(letter).length();
            System.out.printf("  | " + letter + "%9s " + commands.get(letter) + "%"
                    + space_to_the_right + "s", "| ", "|\n");
        }
        line(71, "-", "  ");

    }

    public void get_command_letter_from_user() {
        // asks user input
        System.out.println("\n  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        System.out.print("  Enter the letter for your command here: ");
        // for the do while loop
        boolean invalid = true;
        while (invalid) {

            // enters input
            String inputted_letter = reader.nextLine();
            invalid = is_invalid(inputted_letter);

            // error message for when the input is invalid
            if (invalid)
                System.out.print("\n  '" + inputted_letter
                        + "' is not an option. Only enter the letters above. Input letter here: ");
        }
    }

    public boolean is_invalid(String inputted_letter) {

        /*
         * loop through the command letters to match input to one of them and assign it
         */
        for (int i = 0; i < command_letters.length; i++) {
            // checks if the input match one of the command letters
            if (command_letters[i].equals(inputted_letter.toUpperCase())) {
                // sets the inputted letter to current_command_letter parameter
                current_command_letter = command_letters[i];
                return false;
            }
        }
        return true;

    }

    void display_command_description() {
        // formats the description of the command the user chose by capitalizing the
        // last letter
        String command_description =
                commands.get(current_command_letter).substring(0, 1).toLowerCase()
                        + commands.get(current_command_letter).substring(1);

        // displays the command the user chose
        System.out.println("\n\nYou chose to " + command_description);

        // line under the command description
        line(command_description.length() + 13, "*", "");
        System.out.print("\n\n");
    }

    static public void prompt(String prompt, int space_to_the_left) {
        System.out.print("\n");

        for (int i = 0; i < space_to_the_left - 1; i++)
            System.out.print(" ");

        line(prompt.length(), ">", " ");

        for (int i = 0; i < space_to_the_left; i++)
            System.out.print(" ");

        System.out.print(prompt);
    }


}
