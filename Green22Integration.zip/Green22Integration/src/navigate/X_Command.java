
package navigate;

import java.util.ArrayList;

/**
 * X_Command
 */
public class X_Command extends Helper {
    ArrayList<String[]> logged_commands_from_file = new ArrayList<String[]>();

    public X_Command(ArrayList<String[]> logged_commands_from_file) {

        this.logged_commands_from_file = logged_commands_from_file;
    }


    public void run() {

        // checks if the file has less than three commands
        if (this.logged_commands_from_file.size() < 3) {
            System.out.println(
                    "  There must be at least 3 prior movement commands that has been ran");
            line(70);
        } else {
            System.out.println(
                    "  These are the inputs for the movement commands logged in a text file");
            line(70);

            // goes through all the logged commands from the file
            for (int i = 0; i < logged_commands_from_file.size(); i++) {
                
                String[] command = logged_commands_from_file.get(i);

                // checks if it is a retracing command or just a movement commands
                if (command[0].equals("T") || command[0].equals("V") || command[0].equals("A")) {

                    /*
                     * this method displays and executes the movement commands that are being
                     * retraced
                     */
                    retracing_commands(command, i);

                } else {

                    // this method displays and executes the movement command
                    new Move_Swiftbot(command).run(false);
                }
            }

            // displays to the user that Swiftbot has stops moving
            new Move_Swiftbot().movement_finished(true);
        }
    }

    void retracing_commands(String[] command, int current_index) {

        // number commands that be retraced
        int retracing_number = Integer.parseInt(command[1]);

        // the iteration starts at one index before the current index of the loop from the run
        int start = current_index - 1;

        /*
         * loop ends after it subtracts by the number the user chose from the current index of the
         * loop from the run method
         */
        int end = current_index - retracing_number;

        // runs a for loop backward, so the recent commands can be executed first
        for (int i = start; i >= end; i--) {
            // this method displays and executes the movement command
            new Move_Swiftbot(this.logged_commands_from_file.get(i)).run(false);
        }
    }
}
