
package navigate;


public class Movement_Commands extends Helper {

	private int duration = -1;
	private int speed = -1;

	public void main() {

		// inputs duration and speed, and sets them to a class variable
		set_duration_and_speed();

		// creates a string array for the current movement command
		String[] movement_command =
				{current_command_letter, String.valueOf(this.duration), String.valueOf(this.speed)};

		// adds movement_command array to all_movement_commands arraylist
		all_movement_commands.add(movement_command);

		// this method displays executes the movement command
		System.out.println("\n  These are the inputs for the movement command you chose");
		line(70);
		new Move_Swiftbot(movement_command).run(true);
	}

	void set_duration_and_speed() {

		// ask and set duration for SwiftBot's movement
		System.out.println("  Duration of the movement");
		line(70);
		System.out.println(
				"   The movement can last from 1 to 6 seconds. \n\n   How long do you want the SwiftBot to move? ");
		line(43, ">", "   ");
		System.out.print("\n   Enter the number of seconds here: ");
		set_number("duration", 6);
		System.out.println();

		// ask and set speed for SwiftBot's movement

		System.out.println("\n  Speed of the movement");
		line(70);
		System.out.println(
				"   The speed of the Swiftbot can go from 1 to 100 percent. \n\n   How fast do you want the SwiftBot to go? ");
		line(40, ">", "   ");

		System.out.print("\n   Enter the percent number here: ");
		set_number("speed", 100);
		System.out.println();

	}

	void set_number(String purpose, int max_limit) {
		// for the while loop
		boolean invalid = true;

		// loops until user input is not invalid
		while (invalid) {
			// enters input
			String input_string = reader.nextLine();

			// the try/catch block handles the input when it is not a valid integer
			try {

				// If the input is valid, it will break the loop, if not, an error will be caught
				invalid = is_input_valid(input_string, max_limit, purpose);

			} catch (Exception e) {
				// error message for when the input is invalid
				System.out.print("\n   '" + input_string
						+ "' is not a valid input. Only enter a number between 1 to " + max_limit + " here: ");
			}

		}
	}

	boolean is_input_valid(String input_string, int max_limit, String purpose) {
		// the input is an integer
		int input_number = Integer.parseInt(input_string);

		// checks if the integer is above zero and below the max_limit
		if (input_number > 0 && input_number <= max_limit) {
			if (purpose == "duration") {
				// sets the duration to inputted number
				this.duration = input_number;
			} else if (purpose == "speed") {
				// sets the speed to inputted number
				this.speed = input_number;

			}
			// breaks out of the loop
			return false;
		}
		// throwing an error if number is greater than the number of commands
		else
			throw new ArrayIndexOutOfBoundsException();

	}
}
