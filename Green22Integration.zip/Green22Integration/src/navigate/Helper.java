package navigate;

import java.util.ArrayList;
import java.util.Scanner;

// this class will contain class variables and methods that are shared by more than one objects

public class Helper {


    // holds the letter for the command the user chooses
    public static String current_command_letter;

    // holds all the movement and retracing commands
    public static ArrayList<String[]> all_movement_commands = new ArrayList<>();

    // gets the user input for the command letter
    public static Scanner reader = new Scanner(System.in);


    // the two line methods will help draw consistent line under print statements

    static public void line(int n, String pattern, String space) {
        System.out.print(space);
        for (int i = 0; i < n; i++) {
            System.out.print(pattern);
        }
        System.out.println("");
    }

    static public void line(int n) {
        System.out.print("  ");
        for (int i = 0; i < n; i++) {
            System.out.print("-");
        }
        System.out.println("");
    }


}
