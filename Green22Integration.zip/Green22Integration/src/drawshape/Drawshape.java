package drawshape;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import swiftbotressources.*;
//imports required packages

import swiftbot.SwiftBotAPI;

public class Drawshape {
	private static ArrayList<String> SHAPES_DRAWN = new ArrayList<String>();
	private static ArrayList<Double> TIMES_TO_DRAW = new ArrayList<Double>();
	static SwiftBotAPI API =Resources.APIinstance();
	private static double LARGEST_AREA = 0;
	private static String LARGEST_SHAPE;
	private static int SQUARE_COUNT;
	private static int TRIANGLE_COUNT;
	//variable initialisation
	public static boolean programruns = true;
	
	public static void main(String[] args) throws IOException, InterruptedException {
		System.out.println("Welcome to the shape game!");
		System.out.println("In this game you will be able to draw squares and triangles.");
		
        while (programruns) {
        	
            System.out.println("Enter the letter of a shape to draw (S for square, T for triangle or Q to quit): ");
            String input = Resources.userinput().toUpperCase();
            //takes user input from scanner as 'input' and converts it to upper case
            
            if (input.equals("Q")) {
                Quit();
            } else if (input.equals("S")) {
                Square();
            } else if (input.equals("T")) {
                Triangle();
            } else {
                System.out.println("Invalid input. Please try again.");
            }
            //runs the desired function based on user input, and handles invalid input
        }
        programruns = true;
    }
	//main loop
	
	public static void turn_for(double a){
		while (a>=90) {
			turn_ninety_cw();
			a=a-90;
		}
		double FAC_OF_90 = a/90;
		double TIME_TO_TURN= FAC_OF_90*279;
		try {
			API.move(80,-80,(int)TIME_TO_TURN);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//stores the number as a fraction of 90
	}
	//turns the swiftbot x degrees for argument x-180
	
	public static void turn_ninety_cw() {
		try {
			API.move(80,-80,279);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}}
	//turns swiftbot 90 degrees clockwise
	
	public static void Square() throws InterruptedException {
		double sideLength;
		Scanner scanner_sq=new Scanner(System.in);
		//scanner_sq.close();
		while (true) {
            try {
                System.out.println("Enter the side length for the square in cm, within the range of 15-85cm.");
                sideLength = scanner_sq.nextDouble();
                System.out.println("Drawing...");
                break;
            } catch (InputMismatchException e) {
                System.out.println("ERROR. Please enter an integer.");
                scanner_sq.nextLine();
            }}
		//takes input for side length and validates it.
		
		if ((sideLength*sideLength)>LARGEST_AREA) {
			LARGEST_AREA=sideLength*sideLength;
			LARGEST_SHAPE="square";
		}
		//checks if the square drawn is the largest.
		
		double TIME_TO_MOVE=(sideLength/33.15)*1000;
		//calculates time needed for the swiftbot to move to cover the distance of sideLength
		
		double startTime = System.currentTimeMillis();

		int i=0;
		while (i<4) {
			try {
				API.move(80,85,(int)TIME_TO_MOVE);
				TimeUnit.MILLISECONDS.sleep(500);
				turn_ninety_cw();
				TimeUnit.MILLISECONDS.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			i++;
		}

		double endTime = System.currentTimeMillis();
		TIMES_TO_DRAW.add(endTime-startTime);
		
		SQUARE_COUNT=SQUARE_COUNT+1;
		
		SHAPES_DRAWN.add("Square: "+Double.toString(sideLength));
		System.out.println("Finished!!");
		try {
			API.fillUnderlights(0, 255, 0);
			TimeUnit.SECONDS.sleep(2);
			API.fillUnderlights(0, 0, 0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	//function for drawing square
	
	public static void Triangle() throws InterruptedException {
		double a;
		double b;
		double c;
		//initialises side lengths
		
		Scanner scanner_tr=new Scanner(System.in);
		System.out.print("Enter the side lengths of the triangle, between 15-85cm.");
		while (true) {
	        System.out.print("Enter the first side length: ");
	        while (true) {
	        if (scanner_tr.hasNextDouble()) {
	            a = scanner_tr.nextDouble();
	            if (a>=15 && a<=85) {
	            	break;
	            }
	            System.out.println("Invalid input. "+a+" is not in range 15-85cm. Please try again");
	        }
	        else {
	            String invalidInput1= scanner_tr.next();
	            System.out.println("Invalid input: " + invalidInput1+". Please enter a number");
	        }}

	        System.out.print("Enter the second side length: ");
	        while (true) {
		        if (scanner_tr.hasNextDouble()) {
		            b = scanner_tr.nextDouble();
		            if (b>=15 && b<=85) {
		            	break;
		            }
		            System.out.println("Invalid input. "+b+" is not in range 15-85cm. Please try again");
		        } else {
	            String invalidInput2=scanner_tr.next();
		            System.out.println("Invalid input: " + invalidInput2+". Please enter a number");
		        }}

	        System.out.print("Enter the third side length: ");
	        while (true) {
		        if (scanner_tr.hasNextDouble()) {
		            c = scanner_tr.nextDouble();
		            break;
		        } else {
	            String invalidInput=scanner_tr.next();
		            System.out.println("Invalid input: " + invalidInput+". Please enter a number");
		        }}
	        //checks for valid inputs, and takes side lengths if they are valid.

	        if ((a + b > c && b + c > a && a + c > b) && (a>0 && b>0 && c>0)) {
	        	System.out.println("Valid Triangle!");
	        	System.out.println("Drawing...");
	            break;
	        }
	         else {
	        	System.out.println("Invalid side lengths. They do not form a triangle. Try again.");
	        }}
			//takes inputs for side lengths, and loops until they are valid.
        
	        double s = (a + b + c) / 2;
	        double area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
	        //calculates the area using heron's formula
	        
	        SHAPES_DRAWN.add("Triangle: side1-"+Double.toString(a)+"cm  side2-"+Double.toString(b)+"cm  side3-"+Double.toString(c));
	        //adds triangle information to SHAPES_DRAWN.
	        
	        
	        if (area>LARGEST_AREA) {
	        	LARGEST_AREA=area;
	        	LARGEST_SHAPE="triangle";
	        }
	        //sets value for largest shape to triangle, for the file, if it is the largest.
	        
	        TRIANGLE_COUNT=TRIANGLE_COUNT+1;
	        //updates triangle count.
	        
			double cosA = (b*b + c*c - a*a) / (2*b*c);
			double angleA = Math.toDegrees(Math.acos(cosA));
			double cosB = (a*a + c*c - b*b) / (2*a*c);
			double angleB = Math.toDegrees(Math.acos(cosB));
			double cosC = (b*b + a*a - c*c) / (2*b*a);
			double angleC = Math.toDegrees(Math.acos(cosC));
			// calculates angles using cosine rule.
			
			double startTime = System.currentTimeMillis();
			//starts timer.
			
			try {
				a=(a/33.15)*1000;
				API.move(80,85,(int)a);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//moves for side a
			
			TimeUnit.MILLISECONDS.sleep(500);
			turn_for(180-angleC);
			TimeUnit.MILLISECONDS.sleep(500);
			//turns for angle c
			
			try {
				b=(b/33.15)*1000;
				API.move(80,85,(int)b);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//moves for side b
			
			TimeUnit.MILLISECONDS.sleep(500);
			turn_for(180-angleA);
			TimeUnit.MILLISECONDS.sleep(500);
			//turns for angle a
			
			try {
				c=(c/33.15)*1000;
				API.move(80,85,(int)c);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			//moves for side c
			
			double endTime = System.currentTimeMillis();
			//stops the timer
			
			try {
				API.fillUnderlights(0, 255, 0);
				TimeUnit.SECONDS.sleep(2);
				API.fillUnderlights(0, 0, 0);
			} catch (IOException e) {
				e.printStackTrace();
			}
			//turns underlights green for 2 seconds
			
			TIMES_TO_DRAW.add(endTime-startTime);
			//adds the time it took to the TIMES_TO_DRAW arraylist
    }
	//function for drawing triangle
	
	public static void Quit() throws IOException {
		System.out.println("Thank you for playing the shape game.");
		System.out.println("~~~~~~~~~~ GAME OVER ~~~~~~~~~~");
		FileWriter writehandle = new FileWriter("SHAPE_GAME_INFO.txt");
		BufferedWriter bw = new BufferedWriter(writehandle);
		//creates new file
		
		bw.write("The shapes drawn in order are as follows -- "+SHAPES_DRAWN.toString());
		bw.newLine();
		//writes the array of shapes drawn to the file.
		
		bw.write("The largest shape was "+LARGEST_SHAPE+" with an area of "+(int)LARGEST_AREA+"cm^2.");
		bw.newLine();
		//writes the largest shape to the file.
		
		if (TRIANGLE_COUNT>SQUARE_COUNT) {
			bw.write("The shape drawn the most was triangle. It was drawn "+TRIANGLE_COUNT+" times.");
		}
		if (SQUARE_COUNT>TRIANGLE_COUNT) {
			bw.write("The shape drawn the most was square. It was drawn "+SQUARE_COUNT+" times.");
		}
		if (SQUARE_COUNT==TRIANGLE_COUNT) {
			bw.write("Both shapes were drawn the same number of times! They were drawn "+SQUARE_COUNT+" times.");
		}
		//checks which shape had the highest count (which one was drawn the most)
		//and writes the most frequent shape to the file.
		
		double TOTAL_FOR_AVERAGE = 0;
		int i=0;
		while (i < TIMES_TO_DRAW.size()) {
		    TOTAL_FOR_AVERAGE = TOTAL_FOR_AVERAGE+TIMES_TO_DRAW.get(i);
		    i++;
		}
		
		double AVERAGE=TOTAL_FOR_AVERAGE/TIMES_TO_DRAW.size();
		bw.newLine();
		bw.write("The average time to draw all of the shapes was: "+(int)AVERAGE/1000+"s.");
		bw.newLine();
		//calculates and writes the average shape to the file.
		bw.write("Thank you for playing the shape game :) goodbye");
		
		bw.close();
		programruns = false;
		//shuts down program
	}
}
	//function to quit