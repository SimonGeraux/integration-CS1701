package trafficlight;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Scanner;
import javax.imageio.ImageIO;
import com.hopding.jrpicam.exceptions.FailedToRunRaspistillException;
import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;
import swiftbot.SwiftBotAPI;
import swiftbot.SwiftBotAPI.ImageSize;

import swiftbotressources.*;
/**
 * @author: Simon Geraux
 * Last update: 02/03/2023
 * Email: 2207940@brunel.ac.uk
 * This program is used "to navigate the SwiftBot using color codes inputed using the camera" 
 * (as stated in the assignment's guide).
 * 
 * note: 
 * The naming conventions of the methods have not been respected so to comply with the implementation design's labels;
 * instead of using verbs with the first letter lower cased, names with the first letter capitalized were used.
 */
public class TrafficLight {
	static double executionTime = System.currentTimeMillis(); /*register the program's starting time (double)*/
	static SwiftBotAPI swiftBot; /*Initiates the variable for the SwiftBot API.*/
	/*The following variables will keep track of which button has been pressed (booleans).*/
	public static boolean buttonApressed = false, buttonXpressed = false; 
	/*The following variables will keep track of the number of traffic lights encountered (integers).*/ 
	static int trafficLightEncounteredR = 0, trafficLightEncounteredG = 0,trafficLightEncounteredB = 0;
	/**
	 * Initiates the program when the user presses the button A, and ends the program when the user presses the button X.
	 * @param swiftBot Initiates a SwiftBot API instance.
	 * @param while (!buttonApressed && !buttonXpressed) Serves as a way of waiting for a user input by repeatedly checking for a button to be pressed.
	 * @param counter (integer) Increases every ten seconds, passing a waiting period of one minute, the program will stop.
	 * @param userReply (Scanner) Initiates a new Scanner based on system inputs.
	 * @param response (String) Will store the user input by retrieving the content of the next line in the command prompt.
	 */
	public static void main(String[] args) {
		executionTime = System.currentTimeMillis();
		swiftBot = Ressources.APIinstance();
		System.out.println("The program started, press A to begin.\n");
		int counter = 0;
		ButtonListner();
		while (!buttonApressed && !buttonXpressed) {
			Waiting(10000);
			counter++;
			if (counter == 6) {
			System.out.println("no button pressed");
			break;
			}
		}
		if(buttonApressed) {
			SpeedControl("forward");
			TrafficLightSensor();
			/*no other function call is required as the TrafficLightSensor() function will use recursion. It has the inconvenient of limiting the use of return statements*/
		}
		/*As it can be noted, there isn't a need for a verification of the value of button X, the termination part of the system occurs in all instances.*/
		SpeedControl("stop");
		UnderlightColour("");
		executionTime = System.currentTimeMillis() - executionTime;
	    while(true) {
		    System.out.println("Would you like to display the logs? (Yes/No)");
		    String response = Ressources.userinput(); /*The method "nextLine()" has the inconvenient of not permitting a response to a lack of user input.*/
		    if (response.equalsIgnoreCase("Yes")) {
		    	ProgramLog();
		    	break;
		    } 
		    else if (response.equalsIgnoreCase("No")) {
		    	break;
		    } 
		    else {
		    	System.out.println("unregistered input");
		    }	
	    }
		swiftBot.BUTTON_X.removeAllListeners();
		buttonApressed = false;
		buttonXpressed = false; 
		System.out.println("end of program");
	}
	/**
	 * This method is used to avoid repetitions and make the code more readable.
	 * @param time (integer) Takes an input in milliseconds.
	 * The method will then wait for the specified amount of time.
	 */
	public static void Waiting(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Responds to the pressing of button A and X by changing boolean values.
	 * For both listeners, the conditional statement @param else if, will cover the situation where the button has already been pressed.
	 * @param executionTime is changed within this method to get a reliable time span of the program's execution. It has the disadvantage of increasing the coupling with ProgramLog().
	 */
	public static void ButtonListner() {
		swiftBot.BUTTON_A.addListener(new GpioPinListenerDigital() {
			public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
				if (event.getState().isLow() && !buttonApressed) {
					UnderlightColour("yellow");
					WelcomeMessage();
					buttonApressed = true; /*The boolean value is changed at the end so the program doesn't begin before the welcome message was printed.*/
				} 
				else if (event.getState().isLow() && buttonApressed) {
					System.out.println("The program is already running");
				}
			}
		});
		swiftBot.BUTTON_X.addListener(new GpioPinListenerDigital() {
			public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
				if (event.getState().isLow() && buttonXpressed == false) {
					swiftBot.BUTTON_A.removeAllListeners(); /*Because the program is terminating, there is no need for the button A to be responsive from that point.*/
					buttonXpressed = true;
				} 
				else if (event.getState().isLow() && buttonXpressed == true) {
					System.out.println("Already quitting the program");
				}
			}
		});
	}
	/**
	 * Sends a text message to the user indicating that the program has started.
	 * It also mentions how to exit the program.
	 * Each line is separated by a waiting period of 1 seconds.
	 */
	public static void WelcomeMessage() {
		System.out.println("\nTRAFFIC LIGHT");
		Waiting(1000);
		System.out.println("Developed by Simon Geraux");
		Waiting(1000);
		System.out.println("To exit the program, press X");
		Waiting(1000);
		System.out.println("The program will begin shortly\n");
		Waiting(1000);
	}
	/**
	 * Output a message to the user containing information about the execution:
	 * The duration of the program: @param executionTime, converted in minutes.
	 * The number of traffic lights registered: @param totalEncounter
	 * The most frequent color of traffic light encountered: obtained by a series of conditional statements about their respective values.
	 * @param minutesAndSeconds Formats the time span in with only two decimals for a better readability, it returns a String type.
	 * At the end, a waiting period of ten seconds is used to maintain the program running while the user reviews the data.
	 */
	public static void ProgramLog() {
		DecimalFormat minutesAndSeconds = new DecimalFormat("#.##");
		executionTime = executionTime/60000;
		System.out.println("\nThe program ran for "+minutesAndSeconds.format(executionTime)+" minutes.");
		int totalEncounter = trafficLightEncounteredR + trafficLightEncounteredB + trafficLightEncounteredG;
		System.out.println("It encountered "+totalEncounter+" Traffic lights.");
		if (trafficLightEncounteredR>trafficLightEncounteredG && trafficLightEncounteredR>trafficLightEncounteredB) {
			System.out.println("Out of which the most frequent was red, with "+trafficLightEncounteredR+" encounter(s).\n");
		} 
		else if (trafficLightEncounteredG>trafficLightEncounteredR && trafficLightEncounteredG>trafficLightEncounteredB) {
			System.out.println("Out of which the most frequent was green, with "+trafficLightEncounteredG+" encounter(s).\n");
		} 
		else if (trafficLightEncounteredB>trafficLightEncounteredR && trafficLightEncounteredB>trafficLightEncounteredG) {
			System.out.println("Out of which the most frequent was blue, with "+trafficLightEncounteredB+" encounter(s).\n");
		} 
		else if (totalEncounter > 0){
			System.out.println("With an equal amount of two traffic light colours encountered.\n");
		} 
		else {
			System.out.println("No traffic lights were met during this execution.\n");
		}
		Waiting(10000);
	}
	/**
	 * Centralize the change of motion of the SwiftBot
	 * @param value Takes as input a string so to call one of the four presets within the switch statement. (forward, stop, green, left90)
	 * @param initialSpeed and @param greenSpeed are variables used to centralize the speed factors applied to the wheels (integers).
	 * @param case "forward" and @param case "stop" Use a loop system to progressively change the speed value for a linear transition between each state.
	 * One aspect that could be seen as both an advantage or a problem, is the extensive use of the variable initialSpeed. 
	 * In this configuration it facilitates the modifications when changing of surface on which the SwiftBot operates.
	 */
	public static void SpeedControl(String value) {
		int initialSpeed = 50, greenSpeed = 65;
		switch(value) {
		case "forward":
			for (int i=0;i<=initialSpeed;i++) {
				swiftBot.startMove(i,i);
			}
			   break;
		case "stop":
			for (int i=initialSpeed;i>=0;i--) {
				swiftBot.startMove(i,i);
			}
			    break;
		case "green":
			try {
				swiftBot.move(greenSpeed, greenSpeed, 2000);
			} catch (IllegalArgumentException | InterruptedException e) {
				e.printStackTrace();
			}
			break;
		case "left90": /*The name refers to a 90 degree turns on the left side of the SwiftBot.*/
			try {
				swiftBot.move(-initialSpeed, initialSpeed, 900);
			} catch (IllegalArgumentException | InterruptedException e) {
				e.printStackTrace();
			}
			break;
		}
	}
	/**
	 * Centralize the change of colors of the SwiftBot's under lights.
	 * @param colour (String) Takes as input a string referring to one of the colors that composes the switch statement. (red, green, yellow, blue)
	 * @param colourCode It's using an array to allow for the switch statement to focus on the change of value, so that the SwiftBot API will only be called once.
	 * However, @param case "blue" has a different behavior and it will need to call the SwiftBot API independently.
	 */
	public static void UnderlightColour(String colour) {
		int[] colourCode = {0,0,0};
		switch(colour) {
		case "red":
			colourCode[0] = 255;
			break;	
		case "green":
			colourCode[1] = 255;
			break;
		case "yellow":
			colourCode[0] = 255;
			colourCode[1] = 255;
			break;
		case "blue":
			for(int i=0;i<5;i++) {
				try {
					swiftBot.fillUnderlights(0,0,255);
				} catch (IllegalArgumentException | IOException e) {
					e.printStackTrace();
				}
				Waiting(500);
				swiftBot.disableUnderlights();
				Waiting(500);
			}
			break; /*As this case doesn't change the values of the array, if the disabling of all under lights was to fail, their value would be set to 0.*/
		}
		try {
			swiftBot.fillUnderlights(colourCode);
		} catch (IllegalArgumentException | IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Uses the sonar to detect the distance of the SwiftBot from the nearest object and reacts accordingly.
	 * @param distance (double) It will store the length, in centimeters, between the SwiftBot and the nearest object.
	 * @param obstruction (boolean) By setting the value to true at the beginning, we require the sonar to return a value of 20cm at least once before registering a new traffic light. 
	 * @param while(!buttonXpressed) Stops the recursion process when the user presses the button X so to exit the program. 
	 * This last parameter has the inconvenient of increasing the coupling with the ButtonListner() method.
	 */
	public static void TrafficLightSensor() {
		double distance = 0;
		boolean obstruction = true; 
		while(!buttonXpressed) {
			distance = swiftBot.useUltrasound();
			if (distance > 20) {
				obstruction = false;
			} 
			else if (distance < 20 && obstruction) {
				SpeedControl("stop");
				System.out.println("Obstruction on the way, the traffic light detection cannot be performed."); /*requires the user to move the SwiftBot manually.*/
				Waiting(5000); /*time span for the user to interact with the SwiftBot.*/
				SpeedControl("forward");
			}
			else {
				SpeedControl("stop");
				try {
					swiftBot.takeStill("/home/pi/Documents", "TrafficLightPicture", ImageSize.SQUARE_144x144);
					} catch (IOException | FailedToRunRaspistillException | InterruptedException e) {
					e.printStackTrace();
					}
				PictureAnalyser();
				break;
			}
		}
	}
	/**
	 * Heavily inspired by a model on stackoverflow: https://stackoverflow.com/questions/28162488/get-average-color-on-bufferedimage-and-bufferedimage-portion-as-fast-as-possible
	 * 
	 * Uses the image taken by the TrafficLightSensor() method to obtain the RGB value for each pixel and find the most frequent color in the picture.
	 * @param img (BufferedImage) initiates the call of the class ImageIO so to read the picture's file.
	 * @param IMAGE_PATH (String) refers to the location of the picture taken by the TrafficLightSensor() method. Based on a single file so to avoid saturating the SwiftBot's storage.
	 * @param red = 0, green = 0, blue = 0 (long) Initiates the local variables used to store the RGB values of each pixel.
	 * After finding the dominant color it calls a separate method executing the appropriate response.
	 */
	public static void PictureAnalyser() {
		BufferedImage img = null;
		final String IMAGE_PATH = "/home/pi/Documents/TrafficLightPicture.png";
		try {
			img = ImageIO.read(new File(IMAGE_PATH));
		} catch (IOException e) {
			e.printStackTrace();
		}
		long red = 0, green = 0, blue = 0; 
	    for (int x = 0; x < 144; x++) { /*144 refers to the width of the image*/
	        for (int y = 0; y < 144; y++) { /*144 refers to the height of the image*/
	            Color pixel = new Color(img.getRGB(x, y));
	            red += pixel.getRed();
	            green += pixel.getGreen();
	            blue += pixel.getBlue();
	        }
	    }
	    if(red>green && red>blue) {
	    	RedLight();
	    } 
	    else if(green>red && green>blue) {
	    	GreenLight();
	    } 
	    else if(blue>red && blue>green) {
	    	BlueLight();
	    }
	}
	/**
	 * Protocol in response to identifying a red traffic light.
	 */
	public static void RedLight() {
		trafficLightEncounteredR++;
		UnderlightColour("red");
		Waiting(500);
		SpeedControl("forward");
		TrafficLightSensor();
	}
	/**
	 * Protocol in response to identifying a green traffic light.
	 */
	public static void GreenLight() {
		trafficLightEncounteredG++;
		UnderlightColour("green");
		SpeedControl("green");
		Waiting(500);
		UnderlightColour("yellow");
		SpeedControl("forward");
		TrafficLightSensor();
	}
	/**
	 * Protocol in response to identifying a blue traffic light.
	 */
	public static void BlueLight() {
		trafficLightEncounteredB++;
		Waiting(500);
		UnderlightColour("blue");
		SpeedControl("left90");
		SpeedControl("forward");
		Waiting(1000);
		SpeedControl("stop");
		Waiting(500);
		SpeedControl("left90");
		SpeedControl("left90");
		SpeedControl("forward");
		Waiting(1000);
		SpeedControl("left90");
		SpeedControl("forward");
		TrafficLightSensor();
	}
}