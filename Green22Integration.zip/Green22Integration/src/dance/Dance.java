package dance;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import swiftbot.SwiftBotAPI;
import swiftbotressources.*;
	
public class Dance {
	static SwiftBotAPI swiftbot;
	
	public static void main(String[] args) {

		swiftbot = Ressources.APIinstance();

		System.out.println("Welcome to Swiftbot Dance!");
		System.out.println("--------------------------");
		System.out.println("To start, please input a hexadecimal value. This can be one or two characters, spanning from A-F and/or 0-9!");

		Hexadecimal();
		
	/*
	 * This class assigns SwiftBot as a new instance of the SwiftBotAPI class. This is what allows the SwiftBot to be controlled. Then, 
	 * it displays text that welcomes the user to the SwiftBot Dance Task, and asks them for a hexadecimal input to get started. Finally,
	 * the "Hexadecimal()" class is called to continue with the program.
	 */
	}

	public static void Hexadecimal() {
		
			Scanner inputhex = new Scanner(System.in);
			String hexinput = inputhex.nextLine();
			hexinput = hexinput.toUpperCase();

			if (hexinput.matches("^[0-9A-F]{1,2}$")) {
				System.out.println("Enter Operator:");
				System.out.println("------------------------------------------------");
				System.out.println("Your Final Values for this dance are as follows:");
				System.out.println("Your Given hexadecimal value" + hexinput);
				HexadecimalToDecimal(hexinput);
			}

			else {
				System.out.println("Error Application");
				System.out.println("-----------------");
				System.out.println("");
				System.out.println("Error: The character you have chosen for the operator is incorrect!");
				System.out.println("");
				System.out.println("Select from one of the following operators:");
				System.out.println("Type A-F or 0-9 for either character");
				System.out.println("Type one or two characters MAXIMUM");
				System.out.println("");
				System.out.println("Enter Operator:");
				Hexadecimal();
			}
		}

	/*
	 *This class asks for a user input of a Hexadecimal value of either 1 or 2 digits. It then checks whether the input was a correct Hexadecimal
	 *value and if the users input doesn't match the specifications, an error application is displayed. The class then calls on itself and repeats
	 *this on loop until the user enters a Hexadecimal value that meets the specifications. If everything goes well, the program then calls the
	 *next class, HexadecimalToDecimal, with hexinput as its parameter so that it can be used in calculations.
	 */

	public static int HexadecimalToDecimal(String hexinput) {

		String hexdigits = "0123456789ABCDEFabcdef";
		hexdigits.toUpperCase();
		int decimalEquivalent = 0;

		for (int current = 0; current < hexinput.length(); current++) {
			char hexcharacter = hexinput.charAt(current);
			int hexdigit = hexdigits.indexOf(hexcharacter);
			decimalEquivalent = 16 * decimalEquivalent + hexdigit;
		}

		System.out.println("Decimal Equivalent of your hexadecimal:" + decimalEquivalent);
		HexadecimalToOctal(decimalEquivalent, hexinput);
		return decimalEquivalent;
	}
	
	/*
	 * Next up is the HexadecimalToDecimal class, which is exactly what it sounds like: The given hexadecimal value is converted to decimal. This is
	 * done by first creating a string of the possible hexadecimal digits, and then initialising the integer decimalEquivalent to 0. The class then
	 * loops through the hexadecimal digit(s) and multiplies by the appropriate powers with base 16 until there are none left, then stores the total
	 * value in "decimalEquivalent". The decimal equivalent is printed, the next class is called and the value is returned.
	 */

	public static String HexadecimalToOctal(int decimalEquivalent, String hexinput) {
		
		StringBuilder octalEquivalentBuilder = new StringBuilder();
		int tempDecimalEquivalent = decimalEquivalent;
		
		while (tempDecimalEquivalent > 0) {
			int remainder = tempDecimalEquivalent % 8;
			octalEquivalentBuilder.append(remainder);
			tempDecimalEquivalent /= 8;
		}
		
		String octalEquivalent = octalEquivalentBuilder.reverse().toString();
		System.out.println("Octal Equivalent of your hexadecimal:" + octalEquivalent);
		HexadecimalToBinary(decimalEquivalent, hexinput);
		return octalEquivalent;
	}
	/*
	 * This class takes the decimal equivalent we worked out in the HexadecimalToDecimal class and stores it as a temporary version that can be used to
	 * work out the octal equivalent of the users given Hex input without affecting the DecimalEquivalent for later code. This temporary decimal equivalent
	 * is then used to work out the octal equivalent by running a loop that divides the temporary decimal equivalent by 8 and stores the remainder in the
	 * remainder variable. The code then adds each remainder variable to the octal string that we created previously in this class using the append function, 
	 * to create a string of the octal. The temporary decimal equivalent is then divided by 8, as this shifts the the temporary decimal equivalent one digit to the right in the
	 * octal number system. Finally, the octal string is reverse so that it is displayed in the correct order. This is printed to the console, and the next
	 * class is called.
	 */

	public static String HexadecimalToBinary(int decimalEquivalent, String hexinput) {
		
		StringBuilder binaryEquivalentBuilder = new StringBuilder();
		int tempDecimalEquivalent2 = decimalEquivalent;
		
		while (tempDecimalEquivalent2 > 0) {
			int remainder = tempDecimalEquivalent2 % 2;
			binaryEquivalentBuilder.append(remainder);
			tempDecimalEquivalent2 /= 2;
		}
		
		String binaryEquivalent = binaryEquivalentBuilder.reverse().toString();
		System.out.println("Binary Equivalent of your hexadecimal:" + binaryEquivalent);
		swiftBotUnderlights(hexinput, decimalEquivalent, binaryEquivalent, decimalEquivalent, binaryEquivalent);
		return new StringBuilder(binaryEquivalent).reverse().toString();
	}
	/*
	 * This class converts The hex input of the user into its binary equivalent. First, a stringbuilder is used so that the binary equivalent can be stored
	 * as a string when coverted. Then the decimal equivalent is stored to a variable like the previous class, so that again it doesn't change the decimal
	 * equivalent value in future code. The a while loop is ran to keep dividing the decimal equivalent by base 2 and storing the remainder. The code then
	 * appends the remainder (Adds it to the string) and divides it by 2 within the while loop. Finally, the binary string is reversed so that it is in the
	 * correct order, and the system then prints this to the console for the user to see. The next class is called and the code continues.
	 */
	
	public static void swiftBotUnderlights(String hexinput, int decimalEquivalent, String binaryEquivalent2, int octalEquivalent, String binaryEquivalent) {
		
		int redValue = Integer.parseInt(hexinput, 16);
		
		if (redValue > 255) {
			redValue = 255;
		}
		
		System.out.println("Your Red Value is:" + redValue);
		int greenValue = (decimalEquivalent % 80) * 3;
		System.out.println("Your Green Value is:" + greenValue);
		int blueValue = 0;
		
		if (redValue > greenValue) {
			blueValue = redValue;
		}

		if (greenValue > redValue) {
			blueValue = greenValue;
		}
		
		System.out.println("Your Blue Value is:" + blueValue);
		
		try {
			swiftbot.fillUnderlights(redValue, greenValue, blueValue);
			swiftBotMove(octalEquivalent, hexinput, binaryEquivalent);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	/*
	 * This class is for the underlights. Firstly, the value is assigned to the integer version of the hexinput. If this code is not performed, the hex input
	 * can't be used to make the red value integer. Next, the red value is set to be capped at a maximum of 255, as this is the highest value red can be.
	 * The red value is then printed to the console. Next, the green value is calculated by taking the remainder of the decimal equivalent when divided by
	 * 80 and multiplied by 3, which is then printed to the console. If loops are then used to set the green value to the red or the green value, depending on
	 * which is larger. This is then printed to the console. Finally, the program tries to fill the underlights with the calculated values.
	 */

	public static void swiftBotMove(int octalEquivalent, String hexinput, String binaryEquivalent) {
		
		if (octalEquivalent > 100) {
			octalEquivalent = 100;
		}

		else if (octalEquivalent < 50) {
			octalEquivalent = octalEquivalent + 50;
		}

		int speed = octalEquivalent;
		System.out.println("Your SwiftBot Speed is:" + octalEquivalent);
		System.out.println("");
		System.out.println("Enjoy the dance!");
		System.out.println("");
		System.out.println("------------------------------------------------");
			
		for (int a = 0; a < binaryEquivalent.length(); a++) {
			char binaryChar = binaryEquivalent.charAt(a);
			int forwardBack = speed;
			
			if (binaryChar == '0') {
				forwardBack = -speed;
			}
			
			else if (binaryChar == '1') {
					forwardBack = speed;
			}
			
			if (hexinput.length() == 1) {
				
				try {
					swiftbot.move(forwardBack,forwardBack,1000);
				}
				catch (IllegalArgumentException | InterruptedException e) {
					e.printStackTrace();
				}
				swiftbot.stopMove();
			}
			
			if (hexinput.length() == 2) {
				
				try {
					swiftbot.move(forwardBack,forwardBack,500);
				}
				catch (IllegalArgumentException | InterruptedException e) {
				e.printStackTrace();
				}
				swiftbot.stopMove();
			}
			
			try {
				swiftbot.fillUnderlights(0,0,0);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		try {
			continueOrEnd(binaryEquivalent);
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	/*
	 * This class is used to make the swiftbot move. First it sets the speed to a maximum of 100, or adds 50 to any octal value less than 50 so that the robot
	 * isn't too slow. This new octal equivalent is then assigned to the variable speed to make the following code easier to understand, and the system outputs
	 * the speed and a few extra lines for the console to look better. Then a for loop is created to go through each binary digit, and move the robot forwards
	 * or backwards depending on whethera 0 or 1 is read. The robot also makes each move for half a second or a full second, depending on if the user inputted
	 * a 1 digit hex value or 2 digit hex value. Once the robot goes through the full binary tape the robot is instructed to stop moving, and the lights are 
	 * updated to turn off.
	 */
	
	public static void continueOrEnd(String hexinput) throws FileNotFoundException {
	    
		System.out.println("Do you want to enter a new value and go again?");
	    System.out.println("If so, enter y for yes or n for No, and then your next Hexadecimal Value!");
	    
	    Scanner contOrEnd = new Scanner(System.in);
	        String decision = contOrEnd.nextLine();
	        decision = decision.toUpperCase();
	        
	        if (decision.matches("Y")) {
	            Hexadecimal();
	        }
	        
	        else if (decision.matches("N")) {
	            PrintWriter outputFile = new PrintWriter("Givenhexadecimals");
	            String[] givenHexValues = {hexinput};
	            
	            for (int index = 0; index < givenHexValues.length; index++) {
	                outputFile.println(givenHexValues[index]);
	            }
	        }
	        
	        else {
	            System.out.println("-------------------------------------");
	        	System.out.println("You have entered an invalid operator.");
	            System.out.println("Please enter either 'y' for Yes or 'n' for No to decide if you want to dance again!");
	            System.out.println("Enter Operator:");
	            continueOrEnd(hexinput);
	        }
	    }
	}
	/*
	 * This class is used to allow the user to either end the program and thus the robot dance, or conue with the dance. First, the user is asked if they want to
	 * continue or not, and if they enter y (For yes) thehexadecimal class is called and the whole program starts again. If they enter n (For no) the entered 
	 * haxdecimal values are meant to be stored to a separate text file and then the program ends. If the user inputs anything else, an error application is given
	 * and they are prompted to enter a valid input again.
	 */