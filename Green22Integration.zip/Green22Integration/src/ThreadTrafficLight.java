import trafficlight.TrafficLight;

public class ThreadTrafficLight implements Runnable {
	
	@Override
	public void run() {
		TrafficLight.main(null);
	}
}
