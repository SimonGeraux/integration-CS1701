import navigate.Main;

public class ThreadNavigate implements Runnable{

	@Override
	public void run() {
		Main.main(null);
	}
}
