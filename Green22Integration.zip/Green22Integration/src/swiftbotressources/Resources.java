package swiftbotressources;
import java.util.Scanner;

import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;
import trafficlight.*;

import swiftbot.SwiftBotAPI;
/**
 * @author: Simon Geraux
 * Last update: 24/03/2023
 * Email: 2207940@brunel.ac.uk
 * group: green 22
 * This program is used to generate a single SwiftBotAPI for all the tasks used within the TaskListing class.
 * It also centralises the creation of scanners for user input and returns its the string value.
 * Inspiration for the signleton design pattern was obtained on the following link: https://elearning.algonquincollege.com/coursemat/woollar/Courses/Common/OOP-Java/Input/InputCode-Singleton.pdf
 */

public class Resources {
	static SwiftBotAPI swiftBot;
	static GpioPinListenerDigital listener;
	public static SwiftBotAPI APIinstance() {
		if(swiftBot == null) {
			swiftBot = new SwiftBotAPI();
		}
		return swiftBot;
	}
	public static String userinput() {
		Scanner userReply = new Scanner(System.in);
		return userReply.nextLine();	
	}
}