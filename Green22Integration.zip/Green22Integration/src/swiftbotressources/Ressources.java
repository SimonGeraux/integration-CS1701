package swiftbotressources;
import java.util.Scanner;

import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;
import trafficlight.*;

import swiftbot.SwiftBotAPI;

public class Ressources {
	static SwiftBotAPI swiftBot;
	static GpioPinListenerDigital listener;
	public static SwiftBotAPI APIinstance() {
		if(swiftBot == null) {
			swiftBot = new SwiftBotAPI();
		}
		return swiftBot;
	}
	public static String userinput() {
		Scanner userReply = new Scanner(System.in);
		return userReply.nextLine();	
	}
}