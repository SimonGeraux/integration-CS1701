
import swiftbot.SwiftBotAPI;
import swiftbot.SwiftBotAPI.ImageSize;
import swiftbot.SwiftBotAPI.Underlight;
import swiftbotressources.Resources;

import java.io.IOException;

import com.hopding.jrpicam.exceptions.FailedToRunRaspistillException;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;

/**
 * @author: Ilwad Abukor
 * Last update: 24/03/2023
 * Email: 2207940@brunel.ac.uk
 * group: green 22
 * This program is used to test the components of the SwiftBot and return boolean values to communicate its result with the TaskListing class. 
 */

public class TestSwiftbot {
	/**
	 * @param swiftBot (SwiftBotAPI) initiates the swiftbotAPI using a singleton design pattern
	 * @param testCam, testButtons, testButonLights, testUnderLights, testWheels (boolean) store the results of their respective tests.*/
	static SwiftBotAPI swiftBot = Resources.APIinstance();
	static boolean testCam = true, testButtons = true, testButtonLights = true, testUnderLights = true, testWheels = true;

	/**
	 * The main method prints to the user which test is currently performed and calls the relative method.
	 * @param testCamera, testButtons, testButtonLights, testUnderLights, testWheel Are method storing the tests of their respective components.
	 */
	public static void main() {
		System.out.println("\nTesting the camera...");
		testCamera();
		System.out.println("\nTesting the buttons...");
		testButtons();
		System.out.println("\nTesting the button lights...");
		testButtonLights();
		System.out.println("\nTesting the under lights...");
		testUnderLights();
		System.out.println("\nTesting the left wheel...");
		testWheel("left");
		System.out.println("\nTesting the right wheel...");
		testWheel("right");
	}

	/**
	 * the testCamera method takes a picture and catches the exceptions that may occur during the process.
	 * @param filePath, fileName (string) store the file's information about the location and the label respectively.
	 */
	public static void testCamera() {
		// writes to file directory
		String filePath = "/home/pi/Documents";
		String fileName = "TestingCamera";

			// takes a 48x48 image
			try {
				swiftBot.takeStill(filePath, fileName, ImageSize.SQUARE_48x48);
			} catch (FailedToRunRaspistillException | InterruptedException e) {
			} catch (IOException ie) {
				System.out.println("IOException");
			} catch (Exception e) {
				// if Camera is disabled, it will help the user enable it.
				System.out.println("\nCamera may not be enabled");
				System.out.println("Try entering command below: ");
				System.out.println("\'sudo raspi-config nonint do_camera 0\'\n");
				System.out.println("Then reboot using the following command: ");
				System.out.println("\'sudo reboot\'\n");
				testCam = false;
	}
	System.out.println("Camera: verified ");
	}

	/**
	 * The testButtons method initiates a listener for each button on the swiftBot and returns an error for any other use of the event listener.
	 */
	public static void testButtons() {

		// iterates through all buttons
		for (GpioPinDigitalInput button : swiftBot.BUTTONS) {
			// create and register gpio pin listener
			button.addListener(new GpioPinListenerDigital() {
				public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
					// display pin state on console
					if (event.getState().isLow()) {
						System.out.println("	" + event.getPin() + " pressed");
					} else {
						System.out.println(event.getPin() + " button: not verified ");
						testButtons = false;
					}
				}
			});

		}

		// button testing time
		long endTime = System.currentTimeMillis() + 1_000;
		// do nothing while buttons are tested
		while (System.currentTimeMillis() < endTime) {
		}
		System.out.println("Buttons: verified  ");

		// remove event handlers from all buttons
		swiftBot.BUTTON_A.removeAllListeners();
		swiftBot.BUTTON_B.removeAllListeners();
		swiftBot.BUTTON_X.removeAllListeners();
		swiftBot.BUTTON_Y.removeAllListeners();

	}
/**
 * The testButtonLights method turns on the button lights for one second and disables them.
 * If an error occurs during that process it will be caught.
 */
	public static void testButtonLights() {

		try {
			// toggles all lights for one second
			swiftBot.fillButtonLights();
			Thread.sleep(1000);
			swiftBot.disableButtonLights();
			System.out.println("Button Lights: verified ");
		} catch (InterruptedException e) {
			// outputs any errors
			System.out.println("Button Lights: not verified ");
			testButtonLights = false;
		}
	}

	/**
	 * The testUnderLights method turns the under lights to green for 1 second and turns them off.
	 * If an error occurs during that process it will be caught.
	 */
	public static void testUnderLights() {
		try {

			// iterates through all lights and assigns them green
			int[] green = {0, 255, 0};
			for (Underlight underlight : swiftBot.UNDERLIGHTS) {
				swiftBot.setUnderlight(underlight, green, false);
			}

			// keeps the lights at their white intensities for 1 second
			Thread.sleep(1000);

			// updates the lights to their stored green values
			swiftBot.updateUnderlights();
			Thread.sleep(1000);

			// turns off all lights
			swiftBot.disableUnderlights();
			System.out.println("Under lights: verified ");
		} catch (Exception e) {
			System.out.println("Under lights: not verified ");
			testUnderLights = false;
		}
	}

	/**
	 * The testWheel method changes the velocity of one wheel at the time and catches any exception that may occur during that process.
	 */
	public static void testWheel(String wheel) {
		int leftVelocity = 0;
		int rightVelocity = 0;
		if (wheel.equals("left")) {
			leftVelocity = 30;
		} else {
			rightVelocity = 30;
		}

		try {
			swiftBot.move(leftVelocity, rightVelocity, 1000);
			swiftBot.move(-leftVelocity, -rightVelocity, 1000);
			System.out.println("Wheels: verified\n ");
		} catch (InterruptedException e) {
			System.out.println("Wheels: not verified\n ");
			testWheels = false;
		}
	}
}
