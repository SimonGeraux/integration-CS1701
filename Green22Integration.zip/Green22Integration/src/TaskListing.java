import java.io.IOException;

import dance.Dance;
import drawshape.Task1;
import navigate.Main;
import swiftbotressources.Ressources;
import trafficlight.TrafficLight;
import tunnelvision.MainTunnelVision;

public class TaskListing {
	//change the tasks' files by removing the static keyword of the main method
	 public static void main(String[] args) {
		 System.out.println("Code integration of group 22");
		 choiceMenu();
	}
	 public static void choiceMenu() {
		 System.out.println("1 = dance");
		 System.out.println("2 = draw shape");
		 System.out.println("3 = navigate");
		 System.out.println("4 = traffic light");
		 System.out.println("5 = tunnel vision");
		 String userinput = Ressources.userinput();
		 taskchoice(Integer.parseInt(userinput));
	 }
	 
	 public static void taskchoice(int number) {
		 switch(number) {
		 case 1:
		 	 Dance.main(null);
			 break;
		 case 2:
			try {
			Task1.main(null);
			} catch (IOException | InterruptedException e) {
			}
			 break;
		 case 3:
			 Main.main(null);
			 break;
		 case 4:
			 TrafficLight.main(null);
			 break;
		 case 5:
			 try {
				MainTunnelVision.main(null);
			} catch (Exception e) {
			}
			 break;
		 case 0:
			 programend(); //TODO
		 default:
			 System.out.println("unrecognised input");
			 break;
		 }
		 choiceMenu();
	 }
	 public static void programend() {
		 
	 }
}