import java.io.IOException;

import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;

import dance.Dance;
import drawshape.Drawshape;
import navigate.Navigate;
import swiftbot.SwiftBotAPI;
import swiftbotressources.Resources;
import trafficlight.TrafficLight;
import tunnelvision.TunnelVision;

/**
 * @author: Simon Geraux
 * Last update: 24/03/2023
 * Email: 2207940@brunel.ac.uk
 * group: green 22
 * This program is used to navigate between the different tasks implemented by 5 of our group members. 
 * Inspiration for the final count of the taskExecuttion was inspired by my previous work on the traffic light task 8 assignment.
 */

public class TaskListing {
	/**
	 * @param swiftBot (SwiftBotAPI) initiates the swiftbotAPI using a singleton design pattern
	 * @param taskExecutionNumber (integer) initiates a class variable that will keep track of the number of tasks the user runs so to be displayed in the logs.*/
	static SwiftBotAPI swiftBot = Resources.APIinstance();
	static int taskExecutionNumber;
	
	/**
	 * The main method has the unique functionality to call another class and methods that will work on their own through recursion.
	 * The use of recursion limits the use of return values, thus limiting the use of getters and setters.
	 * @param TestSwiftbot.main makes a series of tests on the swiftbot's components to determine which tasks are safe to use without risking an uncaught exception.
	 * @param welcomeMessage credits the members of the group that have their tasks implemented in this program and how to exit the program.
	 * @param taskBreak offers a mean to stop the program all together by simply pressing a button.
	 * @param choiceMenu tells the user how to select a class or exit the program.
	 */
	 public static void main(String[] args) {
		 TestSwiftbot.main();
		 welcomeMessage();
		 taskBreak();
		 choiceMenu();
	}
	 
	 /**
	  * The choiceMenu method tells the user the inputs required to select a task or exit the program.
	  * A series of print statements is then followed by an instance of a scanner waiting for a user response
	  * @param userInput (String)  stores the response from the user and is passed on to the taskChoice method making it the first part of a recursion process between the two.
	  */
	 public static void choiceMenu() {
		 System.out.println("0 = end of program");
		 System.out.println("1 = dance");
		 System.out.println("2 = draw shape");
		 System.out.println("3 = navigate");
		 System.out.println("4 = traffic light");
		 System.out.println("5 = tunnel vision");
		 String userInput = Resources.userinput();
		 taskChoice(userInput);
	 }
	 
	 /**
	  * The taskChoice method will verify that the task chosen by the user is not using malfunctioning components of the swiftbot.
	  * Later on, the task will execute or prompt the user to chose another one.
	  * Finally, once the task is done executing, the number of tasks registered is increased and a call back to the choiceMenu method completes the recursion process.
	  * @param TestSwiftbot stores the boolean variables telling the method if the components are operational.
	  */
	 public static void taskChoice(String number) {
		 switch(number) {
		 case "1":
			 if(TestSwiftbot.testUnderLights && TestSwiftbot.testWheels) {
				 Dance.main(null); 
			 } else {
				 System.out.println("Unable to load this task as some of the components used failed the testing.");
			 }
			 break;
		 case "2":
			 if(TestSwiftbot.testUnderLights && TestSwiftbot.testWheels) {
					try {
						Drawshape.main(null);
						} catch (IOException | InterruptedException e) {
						}	 
			 }else {
				 System.out.println("Unable to load this task as some of the components used failed the testing.");
			 }
			 break;
		 case "3":
			 if(TestSwiftbot.testUnderLights) {
				Navigate.main(null); 
			 }else {
				 System.out.println("Unable to load this task as some of the components used failed the testing.");
			 }
			 break;
		 case "4":
			 if(TestSwiftbot.testUnderLights && TestSwiftbot.testWheels && TestSwiftbot.testCam && TestSwiftbot.testButtons) {
				TrafficLight.main(null); 
			 }else {
				 System.out.println("Unable to load this task as some of the components used failed the testing.");
			 }
			 break;
		 case "5":
			 if(TestSwiftbot.testWheels) {
				 try {
						TunnelVision.main(null);
					} catch (Exception e) {
					}	 
			 }else {
				 System.out.println("Unable to load this task as some of the components used failed the testing.");
			 }
			 break;
		 case "0":
			 programEnd();
		 default:
			 System.out.println("unrecognised input");
			 break;
		 }
		 taskExecutionNumber++;
		 choiceMenu();
	 }
	 /**
	  * The welcomeMessage method stores a series of print statements that introduce the program to the user while crediting the different group members involved with the integration assignment.
	  */
	 public static void welcomeMessage() {
		 System.out.println("Code integration of group Green 22");
		 System.out.println("---------------------------------Credits---------------------------------\n");
		 waitTime(500);
		 System.out.println("Task Dance: developed by Amaan Udhay (student id: 2255007)");
		 waitTime(500);
		 System.out.println("Task Draw Shape: developed by Blend Bajrami (student id:2229627)");
		 waitTime(500);
		 System.out.println("Task Navigate: developed by Ilwad Abukor (student id:1917805)");
		 waitTime(500);
		 System.out.println("Task Traffic Light: developed by Simon Geraux (student id:2207940)");
		 waitTime(500);
		 System.out.println("Task Tunnel Vision: developed by Hanan Abdulaziz Mohamed (student id:2206192)");
		 waitTime(500);
		 System.out.println("To force stop the program at anytime: Press button Y.");
	 }
	 /**
	  * The programEnd method informs the user that the program is ending and sends to the user the number of tasks executed during the program's runtime.
	  * @param taskExecutionNumber stores the total number of tasks executed.
	  * @param swiftBot.BUTTON_Y.removeAllListners() prevents the program exit to throw an exception about the GPIO pins.
	  * @param System.exit(0) stops the program. 
	  */
	 public static void programEnd() {
		 System.out.println("Request for stopping the program registered.");
		 System.out.println(taskExecutionNumber+" Task(s) were played during this execution.");
		 System.out.println("End of program.");
		 swiftBot.BUTTON_Y.removeAllListeners();
		 System.exit(0);
	 }
	 
	 /**
	  * The waitTime method centralizes the Thread.sleep statement as it appears multiple times within the class.
	  * This makes the class more readable.
	  */
	 public static void waitTime(int duration) {
		 try {
			Thread.sleep(duration);
		} catch (InterruptedException e) {
		}
	 }
	 
	 /**
	  * The taskBreak method initiates a listener of button Y which serves as a mean to force stop the program in case an error was to occur at any stage of the program's runtime.
	  */
	 public static void taskBreak(){
		 swiftBot.BUTTON_Y.addListener(new GpioPinListenerDigital() {
				public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event){
					if (event.getState().isLow()) {
						System.out.println("\n\nButton Y pressed, force stop of the program registered.");
						swiftBot.BUTTON_Y.removeAllListeners();
						System.exit(0);
					} 
				}
		 });
	 }
}